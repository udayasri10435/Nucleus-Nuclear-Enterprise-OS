import React, { useState, useEffect, useMemo } from 'react';
import { 
  Activity, 
  Shield, 
  AlertTriangle, 
  Cpu, 
  Users, 
  Settings, 
  Database, 
  Zap, 
  CheckCircle2, 
  XCircle,
  BarChart3,
  Layers,
  Globe,
  Lock,
  Terminal
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';

// Types
interface Microservice {
  id: string;
  name: string;
  language: string;
  tier: 1 | 2 | 3;
  status: 'healthy' | 'degraded' | 'critical';
  latency: number;
  uptime: number;
  domain: string;
}

const LANGUAGES = ['Rust', 'Go', 'Java', 'Python', 'TypeScript', 'C++', 'Ada/SPARK'];
const DOMAINS = ['Reactor Control', 'Radiation Monitoring', 'Personnel', 'Maintenance', 'Supply Chain', 'Compliance', 'Security'];
const TIER_COLORS = {
  1: 'text-red-400 border-red-900/50 bg-red-900/10',
  2: 'text-blue-400 border-blue-900/50 bg-blue-900/10',
  3: 'text-emerald-400 border-emerald-900/50 bg-emerald-900/10',
};

const STATUS_COLORS = {
  healthy: 'bg-emerald-500',
  degraded: 'bg-amber-500',
  critical: 'bg-red-500',
};

// Mock Data Generator
const generateServices = (count: number): Microservice[] => {
  return Array.from({ length: count }).map((_, i) => ({
    id: `svc-${i + 1}`,
    name: `service-${Math.random().toString(36).substring(7)}`,
    language: LANGUAGES[Math.floor(Math.random() * LANGUAGES.length)],
    tier: (Math.random() > 0.8 ? 1 : Math.random() > 0.4 ? 2 : 3) as 1 | 2 | 3,
    status: Math.random() > 0.95 ? 'critical' : Math.random() > 0.85 ? 'degraded' : 'healthy',
    latency: Math.floor(Math.random() * 200) + 10,
    uptime: 99 + Math.random(),
    domain: DOMAINS[Math.floor(Math.random() * DOMAINS.length)],
  }));
};

export default function App() {
  const [services, setServices] = useState<Microservice[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'services' | 'security' | 'compliance'>('overview');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    setServices(generateServices(1000));
    
    const interval = setInterval(() => {
      setServices(prev => prev.map(s => ({
        ...s,
        latency: Math.max(5, s.latency + (Math.random() * 20 - 10)),
        status: Math.random() > 0.99 ? (Math.random() > 0.5 ? 'critical' : 'degraded') : s.status === 'healthy' ? 'healthy' : Math.random() > 0.7 ? 'healthy' : s.status
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const stats = useMemo(() => {
    const critical = services.filter(s => s.status === 'critical').length;
    const degraded = services.filter(s => s.status === 'degraded').length;
    const healthy = services.filter(s => s.status === 'healthy').length;
    
    const langDist = LANGUAGES.map(lang => ({
      name: lang,
      value: services.filter(s => s.language === lang).length
    }));

    const domainHealth = DOMAINS.map(domain => {
      const domainServices = services.filter(s => s.domain === domain);
      const healthScore = (domainServices.filter(s => s.status === 'healthy').length / domainServices.length) * 100;
      return { name: domain, score: Math.round(healthScore) };
    });

    return { critical, degraded, healthy, langDist, domainHealth };
  }, [services]);

  const filteredServices = services
    .filter(s => s.name.includes(searchQuery) || s.domain.toLowerCase().includes(searchQuery.toLowerCase()))
    .slice(0, 50); // Only show top 50 in list for performance

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#e0e0e0] font-mono selection:bg-red-500/30">
      {/* Top Navigation Bar */}
      <header className="border-b border-white/10 bg-black/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-[1600px] mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-red-600 rounded-sm flex items-center justify-center animate-pulse">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tighter uppercase">Nucleus OS</h1>
              <p className="text-[10px] text-white/40 uppercase tracking-widest">Nuclear Enterprise Management</p>
            </div>
          </div>

          <nav className="flex items-center gap-8">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'services', label: 'Services', icon: Layers },
              { id: 'security', label: 'Security', icon: Lock },
              { id: 'compliance', label: 'Compliance', icon: Shield },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={cn(
                  "flex items-center gap-2 text-xs uppercase tracking-widest transition-colors py-2 border-b-2",
                  activeTab === tab.id ? "text-red-500 border-red-500" : "text-white/40 border-transparent hover:text-white/70"
                )}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-4 text-[10px] text-white/40">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              SYSTEM NOMINAL
            </div>
            <div className="h-4 w-px bg-white/10" />
            <div>MAR 28, 2026 11:31 UTC</div>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto p-6 space-y-6">
        {activeTab === 'overview' && (
          <div className="grid grid-cols-12 gap-6">
            {/* Key Metrics */}
            <div className="col-span-12 grid grid-cols-4 gap-6">
              <MetricCard 
                title="Total Microservices" 
                value={services.length} 
                icon={Layers} 
                trend="+12 this month"
              />
              <MetricCard 
                title="Critical Alerts" 
                value={stats.critical} 
                icon={AlertTriangle} 
                color={stats.critical > 0 ? "text-red-500" : "text-white/40"}
                trend="Requires attention"
              />
              <MetricCard 
                title="Average Latency" 
                value={`${Math.round(services.reduce((acc, s) => acc + s.latency, 0) / services.length)}ms`} 
                icon={Activity} 
                trend="-2ms from avg"
              />
              <MetricCard 
                title="System Uptime" 
                value="99.998%" 
                icon={Shield} 
                color="text-emerald-500"
                trend="Tier-1 Verified"
              />
            </div>

            {/* Language Distribution */}
            <div className="col-span-4 bg-white/5 border border-white/10 p-6 rounded-lg">
              <h3 className="text-xs uppercase tracking-widest mb-6 flex items-center gap-2">
                <Terminal className="w-4 h-4 text-blue-400" /> Polyglot Distribution
              </h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stats.langDist}
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {stats.langDist.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4'][index % 7]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid rgba(255,255,255,0.1)', fontSize: '12px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-2 gap-2 mt-4">
                {stats.langDist.map((lang, i) => (
                  <div key={lang.name} className="flex items-center gap-2 text-[10px]">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4'][i % 7] }} />
                    <span className="text-white/60">{lang.name}:</span>
                    <span className="font-bold">{lang.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Domain Health */}
            <div className="col-span-8 bg-white/5 border border-white/10 p-6 rounded-lg">
              <h3 className="text-xs uppercase tracking-widest mb-6 flex items-center gap-2">
                <Globe className="w-4 h-4 text-emerald-400" /> Domain Health Index
              </h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stats.domainHealth}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="name" stroke="rgba(255,255,255,0.4)" fontSize={10} />
                    <YAxis stroke="rgba(255,255,255,0.4)" fontSize={10} />
                    <Tooltip 
                      cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                      contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid rgba(255,255,255,0.1)', fontSize: '12px' }}
                    />
                    <Bar dataKey="score" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Recent Critical Events */}
            <div className="col-span-12 bg-white/5 border border-white/10 rounded-lg overflow-hidden">
              <div className="p-4 border-b border-white/10 flex items-center justify-between">
                <h3 className="text-xs uppercase tracking-widest flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-500" /> Real-time Anomaly Stream
                </h3>
                <span className="text-[10px] text-white/30 uppercase">Live Feed</span>
              </div>
              <div className="divide-y divide-white/5">
                {services.filter(s => s.status === 'critical').slice(0, 5).map(s => (
                  <div key={s.id} className="p-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                      <div>
                        <div className="text-xs font-bold">{s.name}</div>
                        <div className="text-[10px] text-white/40 uppercase tracking-tighter">{s.domain} • {s.language} • Tier {s.tier}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-red-400 font-bold uppercase">Critical Failure</div>
                      <div className="text-[10px] text-white/30">Latency: {Math.round(s.latency)}ms</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'services' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md">
                <Terminal className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                <input 
                  type="text" 
                  placeholder="SEARCH MICROSERVICES..." 
                  className="w-full bg-white/5 border border-white/10 rounded-md py-2 pl-10 pr-4 text-xs focus:outline-none focus:border-red-500/50 transition-colors"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-white/40 uppercase">Filter:</span>
                <select className="bg-white/5 border border-white/10 rounded px-3 py-1 text-[10px] uppercase focus:outline-none">
                  <option>All Tiers</option>
                  <option>Tier 1 (Safety)</option>
                  <option>Tier 2 (Business)</option>
                  <option>Tier 3 (Tools)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredServices.map(service => (
                <ServiceCard key={service.id} service={service} />
              ))}
            </div>
          </div>
        )}

        {activeTab === 'security' && (
          <div className="grid grid-cols-2 gap-6">
             <div className="bg-white/5 border border-white/10 p-6 rounded-lg">
                <h3 className="text-xs uppercase tracking-widest mb-6 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-blue-400" /> Zero-Trust Access Control
                </h3>
                <div className="space-y-4">
                  <SecurityItem label="mTLS Encryption" status="Active" />
                  <SecurityItem label="SPIFFE/SPIRE Identity" status="Enabled" />
                  <SecurityItem label="Network Policies" status="Strict" />
                  <SecurityItem label="Secrets Management" status="Vault-Locked" />
                </div>
             </div>
             <div className="bg-white/5 border border-white/10 p-6 rounded-lg">
                <h3 className="text-xs uppercase tracking-widest mb-6 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-400" /> Supply Chain Security
                </h3>
                <div className="space-y-4">
                  <SecurityItem label="SBOM Generation" status="Automated" />
                  <SecurityItem label="Vulnerability Scanning" status="Continuous" />
                  <SecurityItem label="Base Image Hardening" status="Verified" />
                  <SecurityItem label="Binary Authorization" status="Enforced" />
                </div>
             </div>
          </div>
        )}

        {activeTab === 'compliance' && (
          <div className="bg-white/5 border border-white/10 rounded-lg overflow-hidden">
            <div className="p-6 border-b border-white/10">
              <h3 className="text-xs uppercase tracking-widest flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Regulatory Audit Trail (NRC/IAEA)
              </h3>
            </div>
            <table className="w-full text-left text-[10px]">
              <thead>
                <tr className="border-b border-white/10 bg-white/5">
                  <th className="p-4 font-bold uppercase tracking-widest text-white/40">Timestamp</th>
                  <th className="p-4 font-bold uppercase tracking-widest text-white/40">Service</th>
                  <th className="p-4 font-bold uppercase tracking-widest text-white/40">Action</th>
                  <th className="p-4 font-bold uppercase tracking-widest text-white/40">Operator</th>
                  <th className="p-4 font-bold uppercase tracking-widest text-white/40">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {[...Array(10)].map((_, i) => (
                  <tr key={i} className="hover:bg-white/5 transition-colors">
                    <td className="p-4 text-white/60">2026-03-28 11:31:{30 - i}</td>
                    <td className="p-4 font-bold">reactor-core-monitor-v2</td>
                    <td className="p-4">Configuration Update</td>
                    <td className="p-4">sys-admin-04</td>
                    <td className="p-4">
                      <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded-full border border-emerald-500/30 uppercase text-[8px]">Verified</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>

      {/* Footer / Status Bar */}
      <footer className="fixed bottom-0 left-0 right-0 bg-black border-t border-white/10 h-8 flex items-center px-6 justify-between z-50">
        <div className="flex items-center gap-6 text-[9px] uppercase tracking-widest text-white/30">
          <div className="flex items-center gap-2">
            <Cpu className="w-3 h-3" />
            CPU: 14.2%
          </div>
          <div className="flex items-center gap-2">
            <Database className="w-3 h-3" />
            MEM: 42.8 GB
          </div>
          <div className="flex items-center gap-2">
            <Activity className="w-3 h-3" />
            OPS: 1.2M/s
          </div>
        </div>
        <div className="text-[9px] uppercase tracking-widest text-white/30">
          Nucleus OS v4.2.0-stable • Build 20260328-1131
        </div>
      </footer>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, trend, color = "text-white" }: { title: string, value: string | number, icon: any, trend: string, color?: string }) {
  return (
    <div className="bg-white/5 border border-white/10 p-5 rounded-lg hover:border-white/20 transition-all group">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[10px] uppercase tracking-widest text-white/40">{title}</span>
        <Icon className={cn("w-4 h-4 opacity-40 group-hover:opacity-100 transition-opacity", color)} />
      </div>
      <div className={cn("text-2xl font-bold tracking-tighter", color)}>{value}</div>
      <div className="text-[9px] text-white/20 mt-2 uppercase tracking-widest">{trend}</div>
    </div>
  );
}

function ServiceCard({ service }: { service: Microservice, key?: React.Key }) {
  return (
    <motion.div 
      layout
      className="bg-white/5 border border-white/10 p-4 rounded-lg hover:bg-white/10 transition-colors cursor-pointer group"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className={cn("w-2 h-2 rounded-full", STATUS_COLORS[service.status])} />
          <span className="text-xs font-bold truncate max-w-[150px]">{service.name}</span>
        </div>
        <span className={cn("text-[8px] px-2 py-0.5 rounded border uppercase font-bold", TIER_COLORS[service.tier])}>
          Tier {service.tier}
        </span>
      </div>
      
      <div className="grid grid-cols-2 gap-y-2 text-[10px]">
        <div className="text-white/30 uppercase">Language</div>
        <div className="text-right font-bold text-white/70">{service.language}</div>
        
        <div className="text-white/30 uppercase">Domain</div>
        <div className="text-right font-bold text-white/70 truncate">{service.domain}</div>
        
        <div className="text-white/30 uppercase">Latency</div>
        <div className="text-right font-bold text-blue-400">{Math.round(service.latency)}ms</div>
        
        <div className="text-white/30 uppercase">Uptime</div>
        <div className="text-right font-bold text-emerald-400">{service.uptime.toFixed(3)}%</div>
      </div>

      <div className="mt-4 h-1 bg-white/5 rounded-full overflow-hidden">
        <motion.div 
          className={cn("h-full", STATUS_COLORS[service.status])}
          initial={{ width: 0 }}
          animate={{ width: `${service.uptime}%` }}
        />
      </div>
    </motion.div>
  );
}

function SecurityItem({ label, status }: { label: string, status: string }) {
  return (
    <div className="flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded hover:border-white/20 transition-colors">
      <span className="text-[10px] uppercase tracking-widest text-white/60">{label}</span>
      <span className="text-[10px] uppercase font-bold text-emerald-400">{status}</span>
    </div>
  );
}
